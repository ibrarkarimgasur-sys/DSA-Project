#ifndef APPOINTMENT_MODULE_H
#define APPOINTMENT_MODULE_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class AppointmentNode {
public:
    int appId;
    int patientId;
    string doctor;
    string date;
    string status; // "Scheduled", "Completed", "Cancelled"
    AppointmentNode* next;

    AppointmentNode(int aId, int pId, string doc, string dt, string st = "Scheduled") {
        appId = aId;
        patientId = pId;
        doctor = doc;
        date = dt;
        status = st;
        next = NULL;
    }
};

class AppointmentQueue {
private:
    AppointmentNode* front;
    AppointmentNode* rear;
    string fileName;

    static string trim(const string& str) {
        size_t start = 0;
        while (start < str.size() && (str[start] == ' ' || str[start] == '\t' || str[start] == '\r' || str[start] == '\n')) {
            start++;
        }
        size_t end = str.size();
        while (end > start && (str[end - 1] == ' ' || str[end - 1] == '\t' || str[end - 1] == '\r' || str[end - 1] == '\n')) {
            end--;
        }
        return str.substr(start, end - start);
    }

    static bool isValidDoctorName(const string& doc) {
        string clean = trim(doc);
        if (clean.size() < 2 || clean.size() > 60) return false;
        if (clean.find('|') != string::npos) return false;

        bool hasLetter = false;
        for (size_t i = 0; i < clean.size(); i++) {
            char c = clean[i];
            bool isAlpha = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
            bool isAllowedPunct = (c == ' ' || c == '.' || c == '-' || c == '\'');
            if (!isAlpha && !isAllowedPunct) {
                return false;
            }
            if (isAlpha) hasLetter = true;
        }
        return hasLetter;
    }

    static bool isLeapYear(int y) {
        return (y % 400 == 0) || (y % 4 == 0 && y % 100 != 0);
    }

    // Strict YYYY-MM-DD calendar check (including leap years & month boundaries)
    static bool isValidDate(const string& rawDate) {
        string d = trim(rawDate);
        if (d.size() != 10) return false;
        if (d[4] != '-' || d[7] != '-') return false;

        for (int i = 0; i < 10; i++) {
            if (i == 4 || i == 7) continue;
            if (d[i] < '0' || d[i] > '9') return false;
        }

        int year = (d[0] - '0') * 1000 + (d[1] - '0') * 100 + (d[2] - '0') * 10 + (d[3] - '0');
        int month = (d[5] - '0') * 10 + (d[6] - '0');
        int day = (d[8] - '0') * 10 + (d[9] - '0');

        if (year < 2000 || year > 2100) return false;
        if (month < 1 || month > 12) return false;

        int daysInMonth[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if (isLeapYear(year)) {
            daysInMonth[2] = 29;
        }

        if (day < 1 || day > daysInMonth[month]) return false;
        return true;
    }

    static bool isValidStatus(const string& st) {
        return (st == "Scheduled" || st == "Completed" || st == "Cancelled");
    }

    static bool parseStrictPositiveInt(const string& raw, int& outVal) {
        string s = trim(raw);
        if (s.empty() || s.size() > 9) return false;
        int val = 0;
        for (size_t i = 0; i < s.size(); i++) {
            if (s[i] < '0' || s[i] > '9') return false;
            val = val * 10 + (s[i] - '0');
        }
        if (val <= 0) return false;
        outVal = val;
        return true;
    }

    void swapData(AppointmentNode* a, AppointmentNode* b) {
        int tAppId = a->appId;
        int tPatId = a->patientId;
        string tDoc = a->doctor;
        string tDate = a->date;
        string tStatus = a->status;

        a->appId = b->appId;
        a->patientId = b->patientId;
        a->doctor = b->doctor;
        a->date = b->date;
        a->status = b->status;

        b->appId = tAppId;
        b->patientId = tPatId;
        b->doctor = tDoc;
        b->date = tDate;
        b->status = tStatus;
    }

public:
    AppointmentQueue(string fName = "appointments.txt") {
        front = NULL;
        rear = NULL;
        fileName = fName;
    }

    ~AppointmentQueue() {
        while (front != NULL) {
            AppointmentNode* temp = front;
            front = front->next;
            delete temp;
        }
        rear = NULL;
    }

    AppointmentNode* findAppointment(int appId) {
        if (appId <= 0) return NULL;
        AppointmentNode* curr = front;
        while (curr != NULL) {
            if (curr->appId == appId) return curr;
            curr = curr->next;
        }
        return NULL;
    }

    bool hasScheduledAppointment(int patientId) {
        AppointmentNode* curr = front;
        while (curr != NULL) {
            if (curr->patientId == patientId && curr->status == "Scheduled") {
                return true;
            }
            curr = curr->next;
        }
        return false;
    }

    bool hasDuplicateSlot(int patientId, const string& doctor, const string& date) {
        AppointmentNode* curr = front;
        while (curr != NULL) {
            if (curr->patientId == patientId &&
                curr->doctor == doctor &&
                curr->date == date &&
                curr->status == "Scheduled") {
                return true;
            }
            curr = curr->next;
        }
        return false;
    }

    bool bookAppointment(int appId, int patientId, bool patientExists, string doctor, string date) {
        string cleanDoc = trim(doctor);
        string cleanDate = trim(date);

        if (appId <= 0 || appId > 999999) {
            cout << "Error: Appointment ID must be between 1 and 999999.\n";
            return false;
        }
        if (patientId <= 0 || patientId > 999999) {
            cout << "Error: Patient ID must be between 1 and 999999.\n";
            return false;
        }
        if (!patientExists) {
            cout << "Error: Patient ID " << patientId << " does not exist.\n";
            return false;
        }
        if (!isValidDoctorName(cleanDoc)) {
            cout << "Error: Invalid Doctor Name (2-60 chars, letters/spaces/./-/' only, no '|').\n";
            return false;
        }
        if (!isValidDate(cleanDate)) {
            cout << "Error: Invalid Date. Use real calendar date in YYYY-MM-DD format (2000-2100).\n";
            return false;
        }
        if (findAppointment(appId) != NULL) {
            cout << "Error: Duplicate Appointment ID (" << appId << ").\n";
            return false;
        }
        if (hasDuplicateSlot(patientId, cleanDoc, cleanDate)) {
            cout << "Error: Patient already has a Scheduled appointment with " << cleanDoc << " on " << cleanDate << ".\n";
            return false;
        }

        AppointmentNode* newNode = new AppointmentNode(appId, patientId, cleanDoc, cleanDate, "Scheduled");
        if (rear == NULL) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            rear = newNode;
        }
        saveToFile();
        cout << "Appointment booked (Scheduled) in arrival queue.\n";
        return true;
    }

    void processNext() {
        if (front == NULL) {
            cout << "Appointment queue is empty.\n";
            return;
        }

        AppointmentNode* curr = front;
        while (curr != NULL && curr->status != "Scheduled") {
            curr = curr->next;
        }

        if (curr == NULL) {
            cout << "No Scheduled appointments left to process.\n";
            return;
        }

        curr->status = "Completed";
        saveToFile();
        cout << "Processed Appointment ID " << curr->appId
             << " for Patient ID " << curr->patientId
             << " -> Status: Completed.\n";
    }

    bool cancelAppointment(int appId) {
        if (appId <= 0) {
            cout << "Error: Invalid Appointment ID.\n";
            return false;
        }
        if (front == NULL) {
            cout << "Error: Appointment queue is empty.\n";
            return false;
        }

        AppointmentNode* target = findAppointment(appId);
        if (target == NULL) {
            cout << "Error: Appointment ID " << appId << " not found.\n";
            return false;
        }
        if (target->status == "Completed") {
            cout << "Error: Completed appointment cannot be cancelled.\n";
            return false;
        }
        if (target->status == "Cancelled") {
            cout << "Error: Appointment is already Cancelled.\n";
            return false;
        }

        target->status = "Cancelled";
        saveToFile();
        cout << "Appointment ID " << appId << " status updated to Cancelled.\n";
        return true;
    }

    void sortById() {
        if (front == NULL || front->next == NULL) {
            cout << "Not enough appointments to sort.\n";
            return;
        }
        bool swapped;
        do {
            swapped = false;
            AppointmentNode* curr = front;
            while (curr->next != NULL) {
                if (curr->appId > curr->next->appId) {
                    swapData(curr, curr->next);
                    swapped = true;
                }
                curr = curr->next;
            }
        } while (swapped);
        saveToFile();
        cout << "Appointments sorted by Appointment ID.\n";
    }

    void displayAll() {
        if (front == NULL) {
            cout << "No appointments in queue.\n";
            return;
        }
        AppointmentNode* curr = front;
        cout << "\n--- Appointment Queue (Arrival Order) ---\n";
        while (curr != NULL) {
            cout << "App ID: " << curr->appId
                 << " | Patient ID: " << curr->patientId
                 << " | Doctor: " << curr->doctor
                 << " | Date: " << curr->date
                 << " | Status: " << curr->status << "\n";
            curr = curr->next;
        }
    }

    void saveToFile() {
        ofstream out(fileName.c_str());
        if (!out) return;

        AppointmentNode* curr = front;
        while (curr != NULL) {
            out << curr->appId << "|" << curr->patientId << "|"
                << curr->doctor << "|" << curr->date << "|" << curr->status << "\n";
            curr = curr->next;
        }
        out.close();
    }

    void loadFromFile() {
        ifstream in(fileName.c_str());
        if (!in) return;

        string line;
        int skipped = 0;
        while (getline(in, line)) {
            if (trim(line).empty()) continue;

            size_t p1 = line.find('|');
            size_t p2 = (p1 == string::npos) ? string::npos : line.find('|', p1 + 1);
            size_t p3 = (p2 == string::npos) ? string::npos : line.find('|', p2 + 1);
            size_t p4 = (p3 == string::npos) ? string::npos : line.find('|', p3 + 1);
            size_t p5 = (p4 == string::npos) ? string::npos : line.find('|', p4 + 1);

            if (p1 == string::npos || p2 == string::npos || p3 == string::npos || p4 == string::npos || p5 != string::npos) {
                skipped++;
                continue;
            }

            int appId = 0;
            int patientId = 0;
            if (!parseStrictPositiveInt(line.substr(0, p1), appId) ||
                !parseStrictPositiveInt(line.substr(p1 + 1, p2 - p1 - 1), patientId)) {
                skipped++;
                continue;
            }

            string doctor = trim(line.substr(p2 + 1, p3 - p2 - 1));
            string date = trim(line.substr(p3 + 1, p4 - p3 - 1));
            string status = trim(line.substr(p4 + 1));

            if (appId < 1 || appId > 999999 ||
                patientId < 1 || patientId > 999999 ||
                !isValidDoctorName(doctor) ||
                !isValidDate(date) ||
                !isValidStatus(status) ||
                findAppointment(appId) != NULL) {
                skipped++;
                continue;
            }

            AppointmentNode* newNode = new AppointmentNode(appId, patientId, doctor, date, status);
            if (rear == NULL) {
                front = rear = newNode;
            } else {
                rear->next = newNode;
                rear = newNode;
            }
        }
        in.close();
        if (skipped > 0) {
            cout << "Warning: Skipped " << skipped << " corrupted/invalid appointment record(s) in " << fileName << ".\n";
            saveToFile();
        }
    }
};

#endif
