#include <iostream>
#include <string>
#include <limits>
#include "PatientModule.h"
#include "AppointmentModule.h"

using namespace std;

string trimStr(const string& str) {
    size_t start = 0;
    while (start < str.size() && (str[start] == ' ' || str[start] == '\t' || str[start] == '\r' || str[start] == '\n')) {
        start++;
    }
    size_t end = str.size();
    while (end > start && (str[end - 1] == ' ' || str[end - 1] == '\t' || str[end - 1] == '\r' || str[end - 1] == '\n')) {
        end--;
    }
    return str.substr(start, end - start);
}

// Strict integer reader: rejects "12abc", "12 34", overflows, negatives (when bounded), or blank input
int readIntInRange(const string& prompt, int minVal, int maxVal, bool& eofFlag) {
    eofFlag = false;
    string raw;

    while (true) {
        cout << prompt;
        if (!getline(cin, raw)) {
            eofFlag = true;
            return -1;
        }

        string s = trimStr(raw);
        if (s.empty()) {
            cout << "Invalid input: field cannot be empty. Enter a number (" << minVal << " to " << maxVal << ").\n";
            continue;
        }

        size_t idx = 0;
        bool negative = false;
        if (s[0] == '-' || s[0] == '+') {
            negative = (s[0] == '-');
            idx = 1;
        }

        if (idx >= s.size()) {
            cout << "Invalid input: enter digits only (" << minVal << " to " << maxVal << ").\n";
            continue;
        }

        bool validDigits = true;
        long long acc = 0;
        for (; idx < s.size(); idx++) {
            if (s[idx] < '0' || s[idx] > '9') {
                validDigits = false;
                break;
            }
            acc = acc * 10 + (s[idx] - '0');
            if (acc > 2000000000LL) {
                validDigits = false;
                break;
            }
        }

        if (!validDigits) {
            cout << "Invalid input: enter a valid whole number without letters or symbols.\n";
            continue;
        }

        long long finalVal = negative ? -acc : acc;
        if (finalVal < minVal || finalVal > maxVal) {
            cout << "Out of range: value must be between " << minVal << " and " << maxVal << ".\n";
            continue;
        }

        return (int)finalVal;
    }
}

string readValidatedName(const string& prompt, bool& eofFlag) {
    eofFlag = false;
    string raw;

    while (true) {
        cout << prompt;
        if (!getline(cin, raw)) {
            eofFlag = true;
            return "";
        }

        string s = trimStr(raw);
        if (s.size() < 2 || s.size() > 60) {
            cout << "Invalid input: must be 2 to 60 characters long.\n";
            continue;
        }
        if (s.find('|') != string::npos) {
            cout << "Invalid input: '|' character is not allowed.\n";
            continue;
        }

        bool valid = true;
        bool hasLetter = false;
        for (size_t i = 0; i < s.size(); i++) {
            char c = s[i];
            bool isAlpha = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
            bool isAllowedPunct = (c == ' ' || c == '.' || c == '-' || c == '\'');
            if (!isAlpha && !isAllowedPunct) {
                valid = false;
                break;
            }
            if (isAlpha) hasLetter = true;
        }

        if (!valid || !hasLetter) {
            cout << "Invalid input: use letters only (spaces, '.', '-', '\\'' allowed; no numbers or symbols).\n";
            continue;
        }

        return s;
    }
}

string readValidatedDisease(const string& prompt, bool& eofFlag) {
    eofFlag = false;
    string raw;

    while (true) {
        cout << prompt;
        if (!getline(cin, raw)) {
            eofFlag = true;
            return "";
        }

        string s = trimStr(raw);
        if (s.size() < 2 || s.size() > 100) {
            cout << "Invalid input: disease/notes must be 2 to 100 characters long.\n";
            continue;
        }
        if (s.find('|') != string::npos) {
            cout << "Invalid input: '|' character is not allowed.\n";
            continue;
        }

        bool valid = true;
        bool hasLetter = false;
        for (size_t i = 0; i < s.size(); i++) {
            char c = s[i];
            bool isAlpha = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
            bool isDigit = (c >= '0' && c <= '9');
            bool isAllowed = (c == ' ' || c == '.' || c == ',' || c == '-' || c == '(' || c == ')' || c == '/');
            if (!isAlpha && !isDigit && !isAllowed) {
                valid = false;
                break;
            }
            if (isAlpha) hasLetter = true;
        }

        if (!valid || !hasLetter) {
            cout << "Invalid input: must include letters and avoid special symbols like '|', '@', '#'.\n";
            continue;
        }

        return s;
    }
}

bool isLeapYr(int y) {
    return (y % 400 == 0) || (y % 4 == 0 && y % 100 != 0);
}

string readValidatedDate(const string& prompt, bool& eofFlag) {
    eofFlag = false;
    string raw;

    while (true) {
        cout << prompt;
        if (!getline(cin, raw)) {
            eofFlag = true;
            return "";
        }

        string d = trimStr(raw);
        if (d.size() != 10 || d[4] != '-' || d[7] != '-') {
            cout << "Invalid date format. Strictly use YYYY-MM-DD (e.g., 2026-11-25).\n";
            continue;
        }

        bool digitsOk = true;
        for (int i = 0; i < 10; i++) {
            if (i == 4 || i == 7) continue;
            if (d[i] < '0' || d[i] > '9') {
                digitsOk = false;
                break;
            }
        }
        if (!digitsOk) {
            cout << "Invalid date: year, month, and day must be numeric (YYYY-MM-DD).\n";
            continue;
        }

        int year = (d[0] - '0') * 1000 + (d[1] - '0') * 100 + (d[2] - '0') * 10 + (d[3] - '0');
        int month = (d[5] - '0') * 10 + (d[6] - '0');
        int day = (d[8] - '0') * 10 + (d[9] - '0');

        if (year < 2000 || year > 2100) {
            cout << "Invalid year: must be between 2000 and 2100.\n";
            continue;
        }
        if (month < 1 || month > 12) {
            cout << "Invalid month: must be between 01 and 12.\n";
            continue;
        }

        int daysInMonth[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if (isLeapYr(year)) {
            daysInMonth[2] = 29;
        }

        if (day < 1 || day > daysInMonth[month]) {
            cout << "Invalid day: month " << month << " in " << year << " has 1 to " << daysInMonth[month] << " days.\n";
            continue;
        }

        return d;
    }
}

int main() {
    PatientList patients("patients.txt");
    AppointmentQueue appointments("appointments.txt");

    patients.loadFromFile();
    appointments.loadFromFile();

    bool eofFlag = false;

    while (true) {
        cout << "\n===== Hospital Appointment & Patient System =====\n";
        cout << "1. Register Patient\n";
        cout << "2. Search Patient\n";
        cout << "3. Update Patient\n";
        cout << "4. Delete Patient\n";
        cout << "5. View All Patients\n";
        cout << "6. Sort Patients by ID\n";
        cout << "7. Book Appointment\n";
        cout << "8. Process Next Appointment\n";
        cout << "9. Cancel Appointment\n";
        cout << "10. View Appointment Queue\n";
        cout << "11. Sort Appointments by ID\n";
        cout << "0. Exit\n";

        int choice = readIntInRange("Enter choice (0-11): ", 0, 11, eofFlag);
        if (eofFlag || choice == 0) {
            patients.saveToFile();
            appointments.saveToFile();
            cout << "Exiting...\n";
            break;
        }

        int id, age, appId, patientId;
        string name, disease, doctor, date;

        switch (choice) {
            case 1:
                id = readIntInRange("Patient ID (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                if (patients.findPatient(id) != NULL) {
                    cout << "Error: Patient ID " << id << " already exists. Registration aborted.\n";
                    break;
                }
                name = readValidatedName("Name: ", eofFlag);
                if (eofFlag) break;
                age = readIntInRange("Age (1-130): ", 1, 130, eofFlag);
                if (eofFlag) break;
                disease = readValidatedDisease("Disease/Notes: ", eofFlag);
                if (eofFlag) break;
                patients.registerPatient(id, name, age, disease);
                break;

            case 2:
                id = readIntInRange("Enter Patient ID to search (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                patients.searchPatient(id);
                break;

            case 3:
                id = readIntInRange("Enter Patient ID to update (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                if (patients.findPatient(id) == NULL) {
                    cout << "Error: Patient ID " << id << " not found.\n";
                    break;
                }
                name = readValidatedName("New Name: ", eofFlag);
                if (eofFlag) break;
                age = readIntInRange("New Age (1-130): ", 1, 130, eofFlag);
                if (eofFlag) break;
                disease = readValidatedDisease("New Disease/Notes: ", eofFlag);
                if (eofFlag) break;
                patients.updatePatient(id, name, age, disease);
                break;

            case 4:
                id = readIntInRange("Enter Patient ID to delete (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                patients.deletePatient(id, appointments.hasScheduledAppointment(id));
                break;

            case 5:
                patients.displayAll();
                break;

            case 6:
                patients.sortById();
                break;

            case 7:
                appId = readIntInRange("Appointment ID (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                if (appointments.findAppointment(appId) != NULL) {
                    cout << "Error: Appointment ID " << appId << " already exists. Booking aborted.\n";
                    break;
                }
                patientId = readIntInRange("Patient ID (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                if (patients.findPatient(patientId) == NULL) {
                    cout << "Error: Patient ID " << patientId << " is not registered. Register patient first.\n";
                    break;
                }
                doctor = readValidatedName("Doctor Name: ", eofFlag);
                if (eofFlag) break;
                date = readValidatedDate("Date (YYYY-MM-DD): ", eofFlag);
                if (eofFlag) break;
                appointments.bookAppointment(
                    appId,
                    patientId,
                    true,
                    doctor,
                    date
                );
                break;

            case 8:
                appointments.processNext();
                break;

            case 9:
                appId = readIntInRange("Enter Appointment ID to cancel (1-999999): ", 1, 999999, eofFlag);
                if (eofFlag) break;
                appointments.cancelAppointment(appId);
                break;

            case 10:
                appointments.displayAll();
                break;

            case 11:
                appointments.sortById();
                break;

            default:
                cout << "Invalid choice. Please select a valid option (0-11).\n";
                break;
        }

        if (eofFlag) {
            patients.saveToFile();
            appointments.saveToFile();
            cout << "\nEOF detected. Saving and exiting...\n";
            break;
        }
    }

    return 0;
}
