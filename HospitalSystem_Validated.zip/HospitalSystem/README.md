# Hospital Appointment and Patient Management System (OEL-3)

## Project Structure
- `PatientModule.h` : Singly Linked List implementation for Patient records (Register, Search, Update, Delete, Sort, Strict File Validation & Persistence).
- `AppointmentModule.h` : Arrival Queue (FIFO) implementation for Appointments (Book, Process Next, Cancel, Status Tracking, Sort, Strict Date & File Validation).
- `main.cpp` : Menu-driven console interface with complete input and boundary validation.

## Boundary & Input Validation Included
- **Strict Integer Parsing**: Rejects trailing characters (`12abc`), whitespace-separated numbers (`12 34`), negatives, `0` IDs, empty lines, and integer overflows.
- **Bounded Ranges**: IDs (`1` to `999999`), Age (`1` to `130`), Menu choice (`0` to `11`).
- **Pre-Prompt Existence Checks**: Duplicate Patient/Appointment IDs or unregistered Patient IDs fail immediately before asking remaining fields.
- **Name & Disease Sanitization**: Blocks empty/whitespace-only inputs, numeric-only names (`12345`), and delimiter injection (`|`) that could corrupt `patients.txt` or `appointments.txt`.
- **Calendar Date Validation**: Enforces `YYYY-MM-DD` with valid months (`01-12`), month-specific days, and leap-year rules (`2024-02-29` valid, `2026-02-29` or `2026-04-31` rejected).
- **Duplicate Appointment Slot Prevention**: Blocks booking duplicate active (`Scheduled`) appointments for the same patient, doctor, and date.
- **Safe File Loading**: Safely skips corrupted/malformed lines in `patients.txt` and `appointments.txt` instead of crashing on `stoi()`.

## How to Compile and Run
On Windows (PowerShell / MinGW / VS Code):
```powershell
g++ -std=c++17 main.cpp -o app.exe; .\app.exe
```
On Linux / macOS:
```bash
g++ -std=c++17 main.cpp -o hospital
./hospital
```
