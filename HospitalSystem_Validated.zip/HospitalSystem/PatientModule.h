#ifndef PATIENT_MODULE_H
#define PATIENT_MODULE_H

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class PatientNode {
public:
    int id;
    string name;
    int age;
    string disease;
    PatientNode* next;

    PatientNode(int pId, string pName, int pAge, string pDisease) {
        id = pId;
        name = pName;
        age = pAge;
        disease = pDisease;
        next = NULL;
    }
};

class PatientList {
private:
    PatientNode* head;
    string fileName;

    static string trim(const string& str) {
        size_t start = 0;
        while (start < str.size() && (str[start] == ' ' || str[start] == '\t' || str[start] == '\r' || str[start] == '\n')) {
            start++;
        }
        size_t end = str.size();
        while (end > start && (str[end - 1] == ' ' || str[end - 1] == '\t' || str[end - 1] == '\r' || str[end - 1] == '\n')) {
            end--;
        }
        return str.substr(start, end - start);
    }

    static bool containsPipe(const string& str) {
        return str.find('|') != string::npos;
    }

    static bool isValidName(const string& name) {
        string clean = trim(name);
        if (clean.size() < 2 || clean.size() > 60) return false;
        if (containsPipe(clean)) return false;

        bool hasLetter = false;
        for (size_t i = 0; i < clean.size(); i++) {
            char c = clean[i];
            bool isAlpha = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
            bool isAllowedPunct = (c == ' ' || c == '.' || c == '-' || c == '\'');
            if (!isAlpha && !isAllowedPunct) {
                return false;
            }
            if (isAlpha) hasLetter = true;
        }
        return hasLetter;
    }

    static bool isValidDisease(const string& disease) {
        string clean = trim(disease);
        if (clean.size() < 2 || clean.size() > 100) return false;
        if (containsPipe(clean)) return false;

        bool hasAlpha = false;
        for (size_t i = 0; i < clean.size(); i++) {
            char c = clean[i];
            bool isAlpha = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
            bool isDigit = (c >= '0' && c <= '9');
            bool isAllowed = (c == ' ' || c == '.' || c == ',' || c == '-' || c == '(' || c == ')' || c == '/');
            if (!isAlpha && !isDigit && !isAllowed) {
                return false;
            }
            if (isAlpha) hasAlpha = true;
        }
        return hasAlpha;
    }

    static bool parseStrictPositiveInt(const string& raw, int& outVal) {
        string s = trim(raw);
        if (s.empty() || s.size() > 9) return false;
        int val = 0;
        for (size_t i = 0; i < s.size(); i++) {
            if (s[i] < '0' || s[i] > '9') return false;
            val = val * 10 + (s[i] - '0');
        }
        if (val <= 0) return false;
        outVal = val;
        return true;
    }

    void swapData(PatientNode* a, PatientNode* b) {
        int tId = a->id;
        string tName = a->name;
        int tAge = a->age;
        string tDisease = a->disease;

        a->id = b->id;
        a->name = b->name;
        a->age = b->age;
        a->disease = b->disease;

        b->id = tId;
        b->name = tName;
        b->age = tAge;
        b->disease = tDisease;
    }

public:
    PatientList(string fName = "patients.txt") {
        head = NULL;
        fileName = fName;
    }

    ~PatientList() {
        while (head != NULL) {
            PatientNode* temp = head;
            head = head->next;
            delete temp;
        }
    }

    PatientNode* findPatient(int id) {
        if (id <= 0) return NULL;
        PatientNode* curr = head;
        while (curr != NULL) {
            if (curr->id == id) return curr;
            curr = curr->next;
        }
        return NULL;
    }

    bool registerPatient(int id, string name, int age, string disease) {
        string cleanName = trim(name);
        string cleanDisease = trim(disease);

        if (id <= 0 || id > 999999) {
            cout << "Error: Patient ID must be between 1 and 999999.\n";
            return false;
        }
        if (!isValidName(cleanName)) {
            cout << "Error: Invalid Name (2-60 chars, letters/spaces/./-/' only, no '|').\n";
            return false;
        }
        if (age < 1 || age > 130) {
            cout << "Error: Age must be between 1 and 130.\n";
            return false;
        }
        if (!isValidDisease(cleanDisease)) {
            cout << "Error: Invalid Disease/Notes (2-100 chars, must contain letters, no '|').\n";
            return false;
        }
        if (findPatient(id) != NULL) {
            cout << "Error: Duplicate Patient ID (" << id << ").\n";
            return false;
        }

        PatientNode* newNode = new PatientNode(id, cleanName, age, cleanDisease);
        if (head == NULL) {
            head = newNode;
        } else {
            PatientNode* curr = head;
            while (curr->next != NULL) {
                curr = curr->next;
            }
            curr->next = newNode;
        }
        saveToFile();
        cout << "Patient registered successfully.\n";
        return true;
    }

    void searchPatient(int id) {
        if (id <= 0) {
            cout << "Error: Invalid Patient ID.\n";
            return;
        }
        PatientNode* p = findPatient(id);
        if (p == NULL) {
            cout << "Patient with ID " << id << " not found.\n";
            return;
        }
        cout << "ID: " << p->id
             << " | Name: " << p->name
             << " | Age: " << p->age
             << " | Disease: " << p->disease << "\n";
    }

    bool updatePatient(int id, string name, int age, string disease) {
        if (id <= 0) {
            cout << "Error: Invalid Patient ID.\n";
            return false;
        }
        PatientNode* p = findPatient(id);
        if (p == NULL) {
            cout << "Error: Patient ID " << id << " not found.\n";
            return false;
        }

        string cleanName = trim(name);
        string cleanDisease = trim(disease);

        if (!isValidName(cleanName)) {
            cout << "Error: Invalid Name (2-60 chars, letters/spaces/./-/' only, no '|').\n";
            return false;
        }
        if (age < 1 || age > 130) {
            cout << "Error: Age must be between 1 and 130.\n";
            return false;
        }
        if (!isValidDisease(cleanDisease)) {
            cout << "Error: Invalid Disease/Notes (2-100 chars, must contain letters, no '|').\n";
            return false;
        }

        p->name = cleanName;
        p->age = age;
        p->disease = cleanDisease;
        saveToFile();
        cout << "Patient updated successfully.\n";
        return true;
    }

    bool deletePatient(int id, bool hasActiveAppointment) {
        if (id <= 0) {
            cout << "Error: Invalid Patient ID.\n";
            return false;
        }
        if (head == NULL) {
            cout << "Error: No patient records available.\n";
            return false;
        }
        if (hasActiveAppointment) {
            cout << "Error: Cannot delete patient with an active Scheduled appointment.\n";
            return false;
        }

        PatientNode* curr = head;
        PatientNode* prev = NULL;

        while (curr != NULL && curr->id != id) {
            prev = curr;
            curr = curr->next;
        }

        if (curr == NULL) {
            cout << "Error: Patient ID " << id << " not found.\n";
            return false;
        }

        if (prev == NULL) {
            head = curr->next;
        } else {
            prev->next = curr->next;
        }

        delete curr;
        saveToFile();
        cout << "Patient deleted successfully.\n";
        return true;
    }

    void sortById() {
        if (head == NULL || head->next == NULL) {
            cout << "Not enough patient records to sort.\n";
            return;
        }
        bool swapped;
        do {
            swapped = false;
            PatientNode* curr = head;
            while (curr->next != NULL) {
                if (curr->id > curr->next->id) {
                    swapData(curr, curr->next);
                    swapped = true;
                }
                curr = curr->next;
            }
        } while (swapped);
        saveToFile();
        cout << "Patients sorted by ID.\n";
    }

    void displayAll() {
        if (head == NULL) {
            cout << "No patients registered.\n";
            return;
        }
        PatientNode* curr = head;
        cout << "\n--- Patient Records ---\n";
        while (curr != NULL) {
            cout << "ID: " << curr->id
                 << " | Name: " << curr->name
                 << " | Age: " << curr->age
                 << " | Disease: " << curr->disease << "\n";
            curr = curr->next;
        }
    }

    void saveToFile() {
        ofstream out(fileName.c_str());
        if (!out) return;

        PatientNode* curr = head;
        while (curr != NULL) {
            out << curr->id << "|" << curr->name << "|" << curr->age << "|" << curr->disease << "\n";
            curr = curr->next;
        }
        out.close();
    }

    void loadFromFile() {
        ifstream in(fileName.c_str());
        if (!in) return;

        string line;
        int skipped = 0;
        while (getline(in, line)) {
            if (trim(line).empty()) continue;

            size_t p1 = line.find('|');
            size_t p2 = (p1 == string::npos) ? string::npos : line.find('|', p1 + 1);
            size_t p3 = (p2 == string::npos) ? string::npos : line.find('|', p2 + 1);
            size_t p4 = (p3 == string::npos) ? string::npos : line.find('|', p3 + 1);

            if (p1 == string::npos || p2 == string::npos || p3 == string::npos || p4 != string::npos) {
                skipped++;
                continue;
            }

            int id = 0;
            int age = 0;
            if (!parseStrictPositiveInt(line.substr(0, p1), id) ||
                !parseStrictPositiveInt(line.substr(p2 + 1, p3 - p2 - 1), age)) {
                skipped++;
                continue;
            }

            string name = trim(line.substr(p1 + 1, p2 - p1 - 1));
            string disease = trim(line.substr(p3 + 1));

            if (id < 1 || id > 999999 || age < 1 || age > 130 ||
                !isValidName(name) || !isValidDisease(disease) ||
                findPatient(id) != NULL) {
                skipped++;
                continue;
            }

            PatientNode* newNode = new PatientNode(id, name, age, disease);
            if (head == NULL) {
                head = newNode;
            } else {
                PatientNode* curr = head;
                while (curr->next != NULL) curr = curr->next;
                curr->next = newNode;
            }
        }
        in.close();
        if (skipped > 0) {
            cout << "Warning: Skipped " << skipped << " corrupted/invalid patient record(s) in " << fileName << ".\n";
            saveToFile();
        }
    }
};

#endif
